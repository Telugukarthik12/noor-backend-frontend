import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TourplanComponent } from './tourplan.component';

describe('TourplanComponent', () => {
  let component: TourplanComponent;
  let fixture: ComponentFixture<TourplanComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TourplanComponent]
    });
    fixture = TestBed.createComponent(TourplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
