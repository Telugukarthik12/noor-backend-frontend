import { Component } from '@angular/core';

@Component({
  selector: 'app-tourplan',
  templateUrl: './tourplan.component.html',
  styleUrls: ['./tourplan.component.css']
})
export class TourplanComponent {

}
