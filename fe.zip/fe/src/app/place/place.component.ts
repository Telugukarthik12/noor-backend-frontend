import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Place } from '../place.model';
import { PlaceService } from '../place.service';

@Component({
  selector: 'app-place',
  templateUrl: './place.component.html',
  styleUrls: ['./place.component.css']
})
export class PlaceComponent implements OnInit {

  isCreatePlace: boolean = true;
  place: any;

  constructor(
    private placeService: PlaceService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.place = this.activatedRoute.snapshot.data['place'];
    console.log(this.place);

    if (this.place && this.place.placeId > 0) {
      this.isCreatePlace = false;
    } else {
      this.isCreatePlace = true;
    }
  }

  isFieldInvalid(field: string, form: NgForm): boolean {
    const control = form.controls[field];
    return control.invalid && (control.dirty || control.touched);
  }

  clearForm(form: NgForm): void {
    const confirmation = confirm('Are you sure you want to clear the form?'); // You can customize this confirmation dialog
    if (confirmation) {
      form.resetForm();
      this.place = {
        placeId: 0,
        placeName: '',
        images: '',
        address: '',
        area: '',
        distance: 0,
        description: '',
        tags: ''
      };
    }
  }

  savePlace(placeForm: NgForm): void {
    // Check if the form is valid
    if (placeForm.valid) {
      // If it's a new place, set placeId to 0
      if (this.isCreatePlace) {
        this.place.placeId = 0;
      }
  
      if (this.isCreatePlace) {
        // Create a new place
        this.placeService.savePlace(this.place).subscribe({
          next: (res: Place) => {
            console.log("Place created successfully:", res);
            placeForm.reset();
            this.router.navigate(["/place-list"]);
          },
          error: (err: HttpErrorResponse) => {
            console.error("Error creating place:", err);
            // Optionally: Display an error message to the user
          },
        });
      } else {
        // Update an existing place
        this.placeService.updatePlace(this.place).subscribe({
          next: (res: string) => {
            console.log("Place updated successfully:", res);
            this.router.navigate(["/place-list"]);
          },
          error: (err: HttpErrorResponse) => {
            console.error("Error updating place:", err);
          },
        });
      }
    }
  }

}
