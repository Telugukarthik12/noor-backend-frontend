import { ActivatedRouteSnapshot, ResolveFn, RouterStateSnapshot } from "@angular/router";
import { PlaceService } from "./place.service";
import { inject } from "@angular/core";
import { Observable, of } from "rxjs";
import { Place } from "./place.model";

export const PlaceResolver: ResolveFn<any> =
  (route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot,
    placeService: PlaceService = inject(PlaceService)): Observable<Place> => {

    const placeId = route.paramMap.get("placeId");

    if (placeId) {
      // make api call and get data for given place id
      return placeService.getPlace(Number(placeId));
    } else {
      // create and return empty place details
      const place: Place = {
        placeId: 0,
        placeName: '',
        images: '',
        address: '',
        area: '',
        distance: 0,
        description: '',
        tags: ''
      };

      return of(place);
    }
  };