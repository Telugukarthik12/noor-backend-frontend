export interface Tourplan {
    
}