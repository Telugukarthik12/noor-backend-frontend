export interface User{
    
}