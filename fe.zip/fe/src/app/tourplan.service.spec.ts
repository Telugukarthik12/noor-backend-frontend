import { TestBed } from '@angular/core/testing';

import { TourplanService } from './tourplan.service';

describe('TourplanService', () => {
  let service: TourplanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TourplanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
